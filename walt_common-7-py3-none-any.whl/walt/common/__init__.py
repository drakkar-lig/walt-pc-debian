from walt.common.version import __version__
